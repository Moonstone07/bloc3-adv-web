<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>pet store mvc</title>
</head>
<body>
    <h1>Pet store mvc with mySQL</h1>

    <!-- controller -->
    <?php
    include_once("controllers/PetController.php");

    ?>



</body>
</html>