<?php

include_once("models/config.php");

class PetController
{
    private $config;
    public function __construct($conn)
    {
        $this->config = new petModel($conn);
    }

    public function displayPets()
    {
        $results = $this->config->getPet();
        include "views/petView.php";
    }

    public function PetForm()
    {
        include "views/petForm.php";
    }

    public function insertPet(){
        $name = $_POST['name'];
        $age = $_POST['age'];
        $gender = $_POST ['gender'];
        $color = $_POST['color'];

        if(!$name || !$age || !$gender || !$color){
            echo "Please fill out all fields";
            $this->PetForm();
            return;
        }elseif ($this->config->insertPet($name, $age, $gender, $color)){
            echo "Pet added successfully";
        } else {
            echo "Error adding pet";
        }
        $this->displayPets();
    }
}

$connect2DA = new connectionDA("localhost", "tischa", "3Dj7e9$5i", "tischa79_adv_web");

$controller = new Controller($connect2DA);
