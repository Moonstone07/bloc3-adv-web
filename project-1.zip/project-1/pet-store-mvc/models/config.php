<?php

class connectionDA
{
    public function __construct(public $host, public $username, public $password, public $dbname){
    }
}
?>