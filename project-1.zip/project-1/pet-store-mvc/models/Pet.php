<?php

include_once("models/config.php");

class petModel
{
    private $mysqli;
    private $connectionDA;
    public function __construct($connectionDA)
    {
        $this->connectionDA = $connectionDA;
    }

    public function connect()
    {
        try {
            $mysqli = new mysqli($this->connectionDA->host, $this->connectionDA->username, $this->connectionDA->password, $this->connectionDA->dbname);
            if ($mysqli->connect_errno) {
                throw new Exception("Failed to connect to MySQL: " . $mysqli->connect_error);
            }
            return $mysqli;
        } catch (Exception $e) {
            return false;
        }
    }

    // select all pets from the database
    public function getPet()
    {
        $mysqli = $this->connect();
        if ($mysqli) {
            $result = $mysqli->query("SELECT * FROM pets");
            while ($row = $result->fetch_assoc()) {
                $results[] = $row;
            }
            $mysqli->close();
            return $results;
        } else {
            return false;
        }
    }


    // insert a new pet into the database
    public function insertPet($name, $age, $gender, $color)
    {
        $mysqli = $this->connect();
        if ($mysqli) {
            $stmt = $mysqli->prepare("INSERT INTO pet (name, age, gender, color) VALUES (?, ?, ?, ?)");
            $stmt->bind_param("ssss", $name, $age, $gender, $color);
            $mysqli->close();
            return true;
        } else {
            return false;
        }
    }
}
